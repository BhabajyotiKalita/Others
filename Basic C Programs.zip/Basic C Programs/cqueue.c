#include<stdio.h>
#include<stdlib.h>
#define size 5
void enqueue();
void dequeue();
int overflow();
int underflow();
void display();
int queue[size],rear=-1,front=-1;
int overflow()
{
 if((front==(rear+1)%size)||(front==rear+1))
 return 1;
 else
 return 0;
}
int underflow()
{
if(front==-1&&rear==-1)
return 1;
else
return 0;
}
void enqueue()
{
 int value;
 if(overflow())
 printf("The queue is full\n");
 else
{
 printf("\nEnter the data to insert in the queue:\n");
 scanf("%d",&value);
 if(front==-1&&rear==-1)
 front=rear=0;
 else
 rear=(rear+1)%size;
 queue[rear]=value;
 printf("\nThe value is inserted successfully\n");
}
}
void dequeue()
{
 int dd;
 dd=queue[front];
 if(underflow())
 printf("The queue is empty\n");
 else
{
 if(front==rear) 
 front=rear=-1;
 else
 front=(front+1)%size;
 printf("The deleted item is:%d\n",dd);
}
}
void display()
{
 int i;
 if(front<=rear)
{ 
 for(i=front;i<=rear;i++)
 printf("\n%d\n",queue[i]);
} 
 else
{ 
	for(i=front;i<=size-1;i++)
 	printf("\n%d\n",queue[i]);
 	for(i=0;i<=rear;i++)
 	printf("\n%d\n",queue[i]);
}
}
main()
{ system("clear");
 int ch;

 printf("*************************************************MENU****************************************************\n1.ENQUEUE\n2.DEQUEUE\n3.DISPLAY\n4.EXIT\n");
while(1)
{
printf("\nEnter your choice:\t");
scanf("%d",&ch); 
switch(ch)
{
 case 1:enqueue();
	break;
 case 2:dequeue();
        break;
 case 3:display();
        break;
 case 4: exit(0);
        break; 
default:printf("Wrong choice enter\n");
}
}
}


