#include<stdio.h>
char sign(int x);
char sign(int x)
{
char s;
if(x>=0)
s="P";
else
s="N";
return s;
}
main()
{
int a;
char s;
printf("\n Enter a number: \n");
scanf("%d",&a);
s=(char)sign(a);
printf("\n %c \n",s);
}

