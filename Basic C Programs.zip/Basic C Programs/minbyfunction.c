#include<stdio.h>
int min(int x,int y,int z);
int min(int x,int y,int z)
{
int m;
if(x<y)
{
if(x<z)
m=x;
else
m=z;
}
else
{
if(y<z)
m=y;
else
m=z;
}
return m;
}
main()
{
int a,b,c,m;
printf("\n Enter three numbers: \n");
scanf("%d%d%d",&a,&b,&c);
m=min(a,b,c);
printf("\n Minimum=%d \n",m);
}

