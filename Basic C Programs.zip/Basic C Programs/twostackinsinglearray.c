#include<stdio.h>
#include<stdlib.h>
#define size 5
#define true 1
#define false 0
void push();
void display();
int arr[size],top1=-1,top2=size,sno;
void push()
{
int x;
//printf("\nThere are two stacks to be pushed: They are stack 1 and stack 2\nStack 1 to be pushed from 1st position and stack 2 to be pushed from last position of the array\n");
printf("\nEnter the stack no.\t");
scanf("%d",&sno);
printf("\nEnter the value to be entered\t");
scanf("%d",&x);
if(top1==top2-1)
printf("\nThe stack is full\t");
else 
{
if(sno==1)
{
if(top1<top2-1)
arr[++top1]=x;
}
if(sno==2)
{
if(top1<top2-1)
arr[--top2]=x;
}
else if(sno>2)
printf("\nWrong Choice!!!");
}}
void pop()
{
int dd1,dd2,sn1;
printf("\nEnter the stack number from which you want to pop\t");
scanf("%d",&sn1);
if(sn1==1)
{
	if(top1>=0)
	{
	dd1=arr[top1--];
	printf("\nPopped data is %d",dd1);
	}
	else
        printf("\nNo value to pop");
}
else if(sn1==2)
{        
     	if(top2<size)
	{
	dd2=arr[top2++];
	printf("\nPopped data is %d",dd2);
	}
	else
	printf("\nNo value to pop"); 
}
else
printf("\nWrong Stack Number");
}
void display1()
{
int i,j;
	 if(top1==-1&&top2==size)
	 printf("\nThe Stack is Empty");

else 
{
	printf("\nThe Stack is:\t");
	if(sno==1||sno==2)
{
	for(i=top1;i>=0;i--)
	printf("%d\t",arr[i]);
	for(j=top2;j<size;j++)
	printf("%d\t",arr[j]);
}
else
	printf("\nWrong Choice");
}}
void display2()
{
int i,sn;
printf("\nEnter the stack no to display\t");
scanf("%d",&sn);
if(top1==-1 && top2==size)
{
printf("\nStack is empty");
}
else if(sn==1)
{	
	printf("\nThe stack is\t");
	for(i=top1;i>=0;i--)
	printf("%d\t",arr[i]);
}
else if(sn==2)
{
	printf("\nThe Stack is:\t");
	for(i=top2;i<size;i++)
	printf("%d\t",arr[i]);
}
else
printf("\nNothing to Display");
}
void main()
{
int ch;
system("clear");
while(1)
{
printf("\n\nMENU\n\n1.Push\n\n2.Pop\n\n3.To Display the array\n\n4.To Display the elements of Stack\n\n5.Exit\n");
printf("\nEnter the choice\t");
scanf("%d",&ch);
switch(ch)
{
case 1: push();
	break;
case 2: pop();
        break;
case 3: display1();
	break;
case 4: display2();
	break;
case 5: exit(0);
        break;
default:printf("\nWRONG CHOICE!!!!!");
}}}
