#include<stdio.h>
main()
{
int a=5,s;
s=++a + ++a;
printf("\n %d \n",s);
}

