#include<stdio.h>
char perf(int x);
char perf(int x)
{
int i;
int sum=0;
char p;
for(i=1;i<=x/2;i++)
{
if(x%i==0)
sum=sum+i;
}
if(sum==x)
p="Y";
else
p="N";
return p;
}
main()
{
int a;
char p;
printf("\n Enter a number:");
scanf("%d",&a);
p=perf(a);
printf("\n %c \n",p);
}

