#include<stdio.h>
int factors(int x);
int factors(int x)
{
int f;
int i=1;
if(i<x/2)
{
if(x%i==0)
{
f=i;
return f;
i=i+1;
}
else
i=i+1;
}
}
main()
{
int a,f;
printf("\n Enter a number:");
scanf("%d",&a);
f=factors(a);
printf("\n Factors are: \n %d \n",f);
}

