#include<stdio.h>
long fact(int n);
main()
{
int n,k,num,i;
long term;
printf("\n Enter number of rows:");
scanf("%d",&num);
for(n=0;n<num;i++)
{
for(k=0;k<=n;k++)
printf("  ");
for(k=0;k<=n;k++)
{
term=fact(n)/(fact(k)*fact(n-k));
printf("%6lld",term);
}
printf("\n");
}
}
long fact(int n)
{
long factorial=1ll;
while(n>=1)
{
factorial=factorial*n;
n--;
}
return factorial;
}

