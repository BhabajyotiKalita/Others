#include<stdio.h>
main()
{
int a,b,c;
printf("\n Enter any 3 numbers: \n");
scanf("%d%d%d",&a,&b,&c);
if(a>b)
{
if(a>c)
printf("\n Biggest number=%d \n",a);
else if(c>a)
printf("\n Biggest number=%d \n",c);
}
else if(b>a)
{
if(b>c)
printf("\n Biggest number=%d \n",b);
else if(c>b)
printf("\n Biggest number=%d \n",c);
}
}

