#include<stdio.h>
#include<math.h>
main()
{
float a,b,c,d,x,y;
printf("\n Enter coefficient of x3:");
scanf("%f",&a);
printf("\n Enter coefficient of x2:");
scanf("%f",&b);
printf("\n Enter coefficient of x:");
scanf("%f",&c);
d=b*b-4*a*c;
if(d==0)
{
x=-b/(2*a);
printf("\n The root is %.2f \n",x);
}
else if(d>0)
{
x=(-b+sqrt(d))/(2*a);
y=(-b-sqrt(d))/(2*a);
printf("\n The roots are %.2f and %.2f \n",x,y);
}
}

