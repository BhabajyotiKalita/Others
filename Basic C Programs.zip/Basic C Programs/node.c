#include<stdio.h>
#include<stdlib.h>
struct node {
	int data;
	struct node *next;
	}*head=NULL;
	
       void create()
{
        struct node *temp,*new;
	int i,n,value;
	printf("\nEnter the number of node:\t");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	printf("\nEnter the data of %d node:\t",i);
	scanf("%d",&value);
	new=(struct node*)malloc(sizeof(struct node));
	new->data=value;
	if(head==NULL)
	{
	head=new;
	new->next=NULL;
	}
	else
	{
	temp=head;
	while(temp->next!=NULL)
	temp=temp->next;
	temp->next=new;
	new->next=NULL;
	}
}
}
        void insert_at_beg()
{
        struct node *temp,*new;
	int value;
	printf("Enter the value of node\t");
	scanf("%d",&value);
	new=(struct node*)malloc(sizeof(struct node));
        new->data=value;
        //temp=head;
        temp=new;
        if(head==NULL)
	{
	printf("\nTHE LIST IS EMPTY AND THE INSERTED ELEMENT IS DISPLAYED AS THE FIRST ELEMENT OF LIST \n");
	new->next=NULL;
	}
	else
       
	new->next=head;
 	head=new;
        
}          

       void insert_at_end()
{
	struct node *temp,*new;
        int value;
        printf("enter the data of last element\t ");
        scanf("%d",&value);
        new=(struct node*)malloc(sizeof(struct node));
        new->data=value;
        new->next=NULL;
        if(head==NULL)
        {
	printf("The list is empty and entered data will be taken as the first element of list !!!!!\n");
        head=new;
        head->next=NULL;
        }
        else
        {
        temp=head;
        while(temp->next!=NULL)
        temp=temp->next;
        temp->next=new;
        new->next=NULL;
        }

}
        void del_at_beg()
{
	int dd;
	if(head==NULL)
	printf("\n PLEASE CREATE LIST FIRST INORDER TO DELETE DATA \n");
	else
	{
	dd=head->data;
	printf("The deleted element is: %d ", dd);
	head=head->next;
	}
	
}
         void del_at_end()
{
	struct node *temp,*new;
        int dd;
        if(head==NULL)
	{
        printf("\n PLEASE CREATE LIST FIRST INORDER TO DELETE DATA \n");
	}
        else
        {
 	temp=head;
	if(temp->next==NULL)
	head=NULL;
	
	while(temp->next!=NULL)
	{
	new=temp;
	temp=temp->next;
	}
	dd=temp->data;
	printf("\nThe deleted data is %d ", dd);
	new->next=NULL;
      	
}
}

            void insert_at_pos()
{
struct node *temp,*new;
int i,pos,x;
printf("\nEnter the position to insert the new node\n");
scanf("%d",&pos);
new=(struct node*)malloc(sizeof(struct node));
printf("\nEnter the value of the node\n");
scanf("%d",&x);
new->data=x;
if(pos==1)
{
if(head==NULL)
{
head=new;
head->next=NULL;
}
else
{
new->next=head;
head=new;
}
}
if(pos>1)
{
temp=head;
for(i=1;i<pos-1;i++)
temp=temp->next;
new->next=temp->next;
temp->next=new;
}}
      void delete_at_pos()
{
int i,dd,pos;
struct node *temp;
printf("\nEnter the position you want to delete");
scanf("%d",&pos);
if(pos==1)
{
if(head==NULL)
printf("\nThe list is empty");
else if(head->next==NULL)
{
dd=head->data;
head=NULL;
}
else
{
dd=head->data;
head=head->next;
}
}
if(pos>1)
{
temp=head;
for(i=1;i<pos-1;i++)
temp=temp->next;
dd=temp->next->data;
temp->next=temp->next->next;
}
printf("\nDELETED DATA IS %d",dd);
}

void display()
{
struct node *temp;
if(head==NULL)
printf("\nThe List is empty\n");
else
{
temp=head;
printf("\nTHE LIST IS -\t");
while(temp!=NULL)
{
printf("%d\t",temp->data);
temp=temp->next;
}
}
}

main()
{
	int n;
        system("clear");
	printf("\t\t\t\t\t\t\t\t\t******MENU*******\t\t\t\n");
	printf("\nPRESS 1 TO CREATE A LIST \n");
	printf("\nPRESS 2 TO INSERT A NODE AT BEGINING\n");
	printf("\nPRESS 3 TO INSERT  A NODE AT END\n");
	printf("\nPRESS 4 TO DELETE A NODE FROM BEGINING \n");
	printf("\nPRESS 5 TO DELETE A NODE AT END \n");
        printf("\nPRESS 6 TO INSERT AT ANY POSITIOM\n\nPRESS 7 TO DELETE AT POSITION\n\nPRESS 8 TO DISPLAY\n\nPRESS 9 TO EXIT\n");
        while(1)
        {
        printf("\n\nEnter your choice:\t");
        scanf("%d",&n);
	//system("clear");
	switch(n)
	{
		case 1: {
			 create();
			 break;
			}
		case 2: {
			 insert_at_beg();
			 break;
			}
		case 3: {
			 insert_at_end();
			 break;
			}
		case 4: {
			 del_at_beg();
			 break;
			}
		case 5: {
			 del_at_end();
			 break;
			}
		case 6: {
                        insert_at_pos();
                        break;
                        }                  	
               case 7:  {
                        delete_at_pos();
                        break;  
                        } 
               case 8:  {
                        display();
                        break;
                        }
               case 9: exit(0);
                       break;
               default: printf("\nINVALID CHOICE\n");
       }
      }
     }
