#include<stdio.h>
main()
{
int a,b,newterm;
int i=0;
int j=1;
int sum=0;
float avg;
printf("\nHow many terms?:");
scanf("%d",&a);
for(b=1;b<=a;b++)
{
sum=sum+i;
newterm=i+j;
i=j;
j=newterm;
}
avg=(float)sum/a;
printf("\nSum=%d\n",sum);
printf("\nAverage=%.2f\n",avg);
}
