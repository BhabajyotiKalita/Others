#include<stdio.h>
main()
{
int a,i,sum=0;
printf("\n Enter a number:");
scanf("%d",&a);
for(i=1;i<=a/2;i++)
{
if(a%i==0)
sum=sum+i;
}
if(sum==a)
printf("\n The number is a perfect number.\n");
else
printf("\n The number is not a perfect number.\n");
}

