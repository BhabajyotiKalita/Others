#include<stdio.h>
#include<stdlib.h>
struct node {
	int data;
	struct node *next;
	}*head1=NULL,*head2=NULL;;
	
       void create(int ln)
{
        struct node *temp,*new;
	int i,n,value;
	printf("\nEnter the number of node:\t");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
	printf("\nEnter the data of %d node:\t",i);
	scanf("%d",&value);
	new=(struct node*)malloc(sizeof(struct node));
	new->data=value;
	if(ln==1)
	{
	if(head1==NULL)
        {
        head1=new;
	new->next=NULL;
	}
	else
	{
	temp=head1;
	while(temp->next!=NULL)
	temp=temp->next;
	temp->next=new;
	new->next=NULL;
	}}
	else if(ln==2)
{
        if(head2==NULL)
      {  
        head2=new;
        new->next=NULL;
      }
	else
      {
	temp=head2;
	while(temp->next!=NULL)
	temp=temp->next;
	temp->next=new;
	new->next=NULL;
      }	
}          
}}      
void display1()
{
struct node *temp;
if(head1==NULL)
printf("\nThe First List is empty\n");
else
{
temp=head1;
printf("\nTHE FIRST LIST IS -\t");
while(temp!=NULL)
{
printf("%d\t",temp->data);
temp=temp->next;
}}
if(head2==NULL)
printf("\nThe Second List is empty");
else
{
temp=head2;
printf("\nTHE SECOND LIST IS\t");
while(temp!=NULL)
{
printf("%d\t",temp->data);
temp=temp->next;
}}}
void concatanate()
{
struct node *temp;
if(head1==NULL|| head2==NULL)
printf("\nThere is only  one list");
else
{
temp=head1;
while(temp->next!=NULL)
temp=temp->next;
temp->next=head2;
printf("\nConcatanated Successfully");
}}

void display2()
{
struct node *temp;
if(head1==NULL && head2==NULL)
printf("\nThe List is empty\n");
else if(head1==NULL)
{
temp=head2;
printf("\nTHE LIST IS -\t");
while(temp!=NULL)
{
printf("%d\t",temp->data);
temp=temp->next;
}
}
else if(head2==NULL)
{
temp=head1;
printf("\nThe list is:\t");
while(temp!=NULL)
{
printf("%d\t",temp->data);
temp=temp->next;
}
}
else
{
temp=head1;
printf("\nThe list is:\t");
while(temp!=NULL)
{
printf("%d\t",temp->data);
temp=temp->next;
}
}}
main()
{
	int n,ln;
        system("clear");
	while(1)
	{
	printf("\n\t\t\t\t\t\t\t\t\t******MENU*******\t\t\t\n");
	printf("\nPRESS 1 TO CREATE LIST");
	printf("\nPRESS 2 TO DISPLAY INDIVIDUAL LISTS");
	printf("\nPRESS 3 TO CONCATANATE");
	printf("\nPRESS 4 TO DISPLAY CONCATANATE  LINKED LIST\n"); 
	printf("\nPRESS 5 TO EXIT");
        printf("\n\nEnter your choice:\t");
        scanf("%d",&n);
	//system("clear");
	switch(n)
	{
		case 1: {
			printf("\nEnter the list no:\t");
			scanf("%d",&ln);
			create(ln);
			 break;
			}
		case 2: display1();
			break;
               case 3:  {
                        concatanate();
                        break;
                        }
		case 4:display2();
			break;
		case 5: exit(0);
                       break;
               default: printf("\nINVALID CHOICE\n");
       }
      }
     }
