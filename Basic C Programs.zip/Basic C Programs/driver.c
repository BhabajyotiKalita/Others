#include<stdio.h>
main()
{
int status,gender,age;
printf("\n Enter 1 for married and 2 for unmarried:");
scanf("%d",&status);
if(status==1)
printf("\n The driver is insured.\n");
else if(status==2)
{
printf("\n Enter 1 for male and 2 for female:");
scanf("%d",&gender);
if(gender==1)
{
printf("\n Enter age:");
scanf("%d",&age);
if(age>30)
printf("\n The driver is insured.\n");
else
printf("\n The driver is not insured.\n");
}
else if(gender==2)
{
printf("\n Enter age:");
scanf("%d",&age);
if(age>25)
printf("\n The driver is insured.\n");
else
printf("\n The driver is not insured.\n");
}
}
}

