#include<stdio.h>
main()
{
int n,a,b,min,max,sum=0;
float avg;
printf("\n How many terms?:");
scanf("%d",&n);
for(a=1;a<=n;a++)
{
scanf("%d",&b);
if(a==1)
{
min=b;
max=b;
}
if(b<min)
min=b;
if(b>max)
max=b;
sum=sum+b;
}
avg=(float)sum/n;
printf("\n Minimum=%d \n",min);
printf("\n Maximum=%d \n",max);
printf("\n Sum=%d \n",sum);
printf("\n Average=%.2f \n",avg);
}

