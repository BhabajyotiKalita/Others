#include<stdio.h>
main()
{
int a;
float temp,b;
printf("\n Enter 1 to convert temperature value from Fahrenheit scale to Centigrade scale.\n Enter 2 to convert temperature value from Centigrade scale to Fahrenheit scale.\n");
scanf("%d",&a);
if(a==1)
{
printf("\n Enter temperature in Fahrenheit scale:");
scanf("%f",&temp);
b=(temp-32)*5/9;
printf("\n Temperature in Centigrade Scale=%.2f\n",b);
}
else if(a==2)
{
printf("\n Enter temperature in Centigrade scale:");
scanf("%f",&temp);
b=(temp*9/5)+32;
printf("\n Temperature in Fahrenheit Scale=%.2f\n",b);
}
}

