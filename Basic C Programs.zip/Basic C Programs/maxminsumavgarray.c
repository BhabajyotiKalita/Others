#include<stdio.h>
main()
{
int arr[100],a,i;
int max=0;
int min=100000;
int sum=0;
float avg;
printf("\n How many elements?:");
scanf("%d",&a);
printf("\n Enter the elements:");
for(i=0;i<a;i++)
scanf("%d",&arr[i]);
for(i=0;i<a;i++)
{
if(max<arr[i])
max=arr[i];
}
printf("\n Maximum=%d\n",max);
for(i=0;i<a;i++)
{
if(min>arr[i])
min=arr[i];
}
printf("\n Minimum=%d\n",min);
for(i=0;i<a;i++)
sum=sum+arr[i];
printf("\n Sum=%d\n",sum);
avg=(float)sum/a;
printf("\n Average=%.2f\n",avg);
}

