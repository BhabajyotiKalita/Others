#include<stdio.h>
#include<stdlib.h>
struct node{
        int data;
        struct node *next,*prev;
        }*front=NULL,*rear=NULL;
void enqueue()
{
        struct node *new;
        int value;
        printf("\nENTER THE VALUE TO BE INSERTED IN QUEUE\t ");
        scanf("%d",&value);
        new=(struct node*)malloc(sizeof(struct node));
        new->data=value;
        new->next=NULL;
        if(front==NULL)
        {
	new->prev=NULL;
        rear=new;
        front=new;
        }
        else
        {
	 new->prev=rear->next;
         rear->next=new;
         rear=new;
	 
        }
        printf("\n DATA %d IS SUCCESFULLY INSERTED AT %u",rear->data,rear);
}
void dequeue()
{
        struct node *temp;
        if(front==NULL)
        printf("\nQUEUE UNDERFLOW \n");
        else
        {
 
	temp=front;
        printf("The deleted element is %d ",temp->data);
        
        
	//if(front==rear)
	if(front->next==NULL)
        front=NULL;
	else
	{

	front=front->next;
	front->prev=NULL;
	}
        }
}            
void display()
{
        struct node *temp;
        if(front==NULL)
        printf("\nQUEUE UNDERFLOW\n");
        else
        {
        temp=front;
        printf("\nQUEUE IS -\t");
        while(temp!=NULL)
        {
        printf("%d\t",temp->data);
        temp=temp->next;
        }
}

}
main()
{
        int ch;
        while(1)
        {
        printf("\nPRESS 1 TO ENQUEUE \nPRESS 2 TO DEQUEUE \nPRESS 3 TO DISPLAY \nPRESS 4 TO EXIT \n");
        scanf("%d",&ch);
        switch(ch)
        {
        case 1:
                enqueue();
                break;
        case 2:
                dequeue();
                break;
        case 3:
                display();
                break;
        case 4:
                exit(0);
        default: printf("\nINCORRECT CHOICE !!!!\n");
}
}
}

