#include<stdio.h>
int max(int x,int y);
int max(int x,int y)
{
int m;
if(x>y)
m=x;
else
m=y;
return m;
}
main()
{
int a,b,m;
printf("\n Enter two numbers: \n");
scanf("%d%d",&a,&b);
m=max(a,b);
printf("\n Maximum=%d \n",m);
}
