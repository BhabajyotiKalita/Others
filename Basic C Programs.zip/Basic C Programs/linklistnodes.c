#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next;
}
*head=NULL;
void create()
{
int n,value,i;
struct node *temp,*new;
printf("\n How many nodes do u want?");
scanf("%d",&n);
i=1;
while(i<=n)
{
printf("\n Enter dataa of the node %d",i);
scanf("%d",&value);
new=(struct node *)malloc(sizeof(struct node));
new->data=value;
if(head==NULL)
{
head=new;
new->next=NULL;
}
else
{
temp=head;
while(temp->next!=NULL)
{
temp=temp->next;
}
temp->next=new;
new->next=NULL;
}
i++;
}
void insertatbig()
{
struct node *new;
int value;
printf("\n Enter the value to insert at bigining:");
scanf("%d",&value);
new=(struct node *)malloc(sizeof(struct node));
new->data=value;
if(head==NULL)
new->next=NULL;
else
new->next=head;
head=new;
}
void display()
{
struct node *temp;
if(head==NULL)
printf("\n The list is empty \n");
else
{
printf("\n The list is: \n");
temp=head;
while(temp!=NULL)
{
printf("%d",temp->data);
temp=temp->next;
}
}
}
main()
{
int choice;
while(1)
{
system("clear");
printf("\n ****MENU**** \n");
printf("\n 1. Create()
\n 2. Insertatbig()
\n 3. Display()
\n 4. Exit()
\n");
printf("\n Enter your choice: ");
scanf("%d",&choice);
switch(choice)
{
case 1:create();
break;
case 2:insertatbig();
break;
case 3:display();
break;
case 4:exit(0);
default:printf("\n Invalid Choice \n");
}
}
}


