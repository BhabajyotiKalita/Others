#include<stdio.h>
main()
{
float n,comm;
printf("\n Enter sales:");
scanf("%f",&n);
if(n<=500)
comm=n*0.05;
else if((n>500)&&(n<=2000))
comm=35+500*0.10;
else if((n>2000)&&(n<=5000))
comm=185+2000*0.12;
else if(n>5000)
comm=n*0.125;
printf("\n Commission=%.2f \n",comm);
}

