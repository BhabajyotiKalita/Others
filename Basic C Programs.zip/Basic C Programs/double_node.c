#include<stdio.h>
#include<stdlib.h>
struct node
{
int data;
struct node *next,*prev;
}*head=NULL,*tail=NULL;
void create()
{
int n,value,i;
struct node *temp, *new;
printf("\nEnter the no. of nodes you  want");
scanf("%d",&n);
i=1;
while(i<=n)
{
printf("enter the data of %d node",i);
scanf("%d",&value);
new=(struct node*)malloc(sizeof(struct node));
new->data=value;
if(head==NULL)
{
head=new;
tail=new;
new->next=NULL;
new->prev=NULL;
}
else
{
temp=head;
while(temp->next!=NULL)
temp=temp->next;
temp->next=new;
new->prev=temp;
new->next=NULL;
}
i++;
}}
void insert_at_beg()
{
int x;
struct node *temp,*new;
new=(struct node*)malloc(sizeof(struct node));
printf("\nEnter the item to insert at beg");
scanf("%d",&x);
new->data=x;
if(head ==NULL)
{
new->prev=NULL;
new->next==NULL;
head = new;
tail=new;
}
else
{
new->next =head;
new->prev=NULL;
head=new;
}
}
void insert_at_end()
{
struct node *temp,*new;
int x;
printf("\nEnter the value to be inserted\n");
scanf("%d",&x);
new=(struct node*)malloc(sizeof(struct node));
new->data=x;
if(head==NULL)
{
head=new;
tail=new;
new->next=NULL;
new->prev=NULL;
}
else
{
temp=head;
while(temp->next!=NULL)
temp=temp->next;
temp->next=new;
new->prev=temp;
tail=new;
}}
void del_at_beg()
{
struct node *temp;
if(head==NULL)
printf("\nTHE LIST IS EMPTY");
else
{
temp=head;
head=head->next;
temp->prev=NULL;
temp->next=NULL;
}}
void del_at_end()
{
struct node *temp,*loc;
if(head==NULL)
printf("\nThe list is empty");
else
{
temp=head;
while(temp->next!=NULL)
{
loc=temp;
temp=temp->next;
}
temp->prev=NULL;
loc->next=NULL;
}}

void insert_at_pos()
{
struct node *temp,*new;
int pos,x,i;
printf("\nEnter the position where you want to insert the data\t");
scanf("%d",&pos);
printf("\nEnter the value of the data\t");
scanf("%d",&x);
new=(struct node*)malloc(sizeof(struct node));
new->data=x;
if(pos==1)
{
if(head==NULL)
{
new->next=new->prev=NULL;
head=tail=new;
}
else
{
new->next=head;
new->prev=NULL;
head=new;
}}
else if(pos>1)
{
temp=head;
for(i=1;i<pos-1;i++)
temp=temp->next;
new->next=temp->next;
temp->next=new;
}}
void delete_at_pos()
{
struct node *temp;
int i,pos,dd;
printf("\nEnter the position where you want to delete the data");
scanf("%d",&pos);
if(pos==1)
{
if(head==NULL)
printf("\nThe list is empty");
else
{
temp=head;
head=head->next;
dd=temp->data;
temp->next=NULL;
temp->prev=NULL;
}}
else if(pos>1)
{
temp=head;
for(i=1;i<pos-1;i++)
temp=temp->next;
dd=temp->next->data;
temp->next=temp->next->next;
}
printf("\nDeleted Data is %d",dd);
}
void display()
{
struct node *temp;
if (head==NULL)
printf("The list is empty");
else
{
printf("the list is :");
temp =head;
while(temp!=NULL)
{
printf("%d\t",temp->data);
temp=temp->next;
}
}
}
main()
{
int choice;
system ("clear");
printf("\nMenu");
printf("\n1.Create \n2.Inster_at_Beginning \n3.Insert at end\n4.delete at beginning\n5.\nDelete at End\n6.Insert at position\n7.Delete at position\n8.Display\n9.Exit");
while(1)
{
printf("\nEnter your choice:");
scanf("%d",&choice);
switch(choice)
{
case 1:{
 create();
break;
}
case 2:{
insert_at_beg();
break;
}
case 3:{
insert_at_end();
break;
}
case 4:{
del_at_beg();
break;
}
case 5:{
del_at_end();
break;
}
case 6:
insert_at_pos();
break;
case 7:
delete_at_pos();
break;
case 8:display();
break;
case 9:exit(0);
default:
printf("\nWrong Choice");
}}}

