#include<iostream>
#include<iomanip>
#include<cstdlib>
using namespace std;

class Time
{

private:
int hh,mm,ss;

public:

Time(int h=0,int m=0,int s=0)

{

if(h>=24 || m>=60 || s>=60)
{
	cout<<"Wrong Input"<<endl;
	exit(0);
}
else
{
	hh=h;
	mm=m;
	ss=s;
}
}

Time operator++()

{
 	Time temp;
 	temp.ss=++ss;
 	if(ss==60)
 	{
	mm=mm+1;
 	ss=0;
	}
	if(mm==60)
	{
	hh=hh+1;
 	mm=0;
	}
	if(hh==24)
	hh=0;
 	return (temp);
}

Time operator--()	
{
Time temp1;
temp1.ss=--ss;
if(ss==-1 && mm==0)
{
ss=59;
mm=59;

}
else if(ss==-1 && mm!=0 && mm!=1)
{
ss=59;
mm=mm-1;
}

if(ss==59 && mm==59 && hh!=0)
hh=hh-1;

if(ss==59 && mm==59 && hh==0)
hh=23;

else if(ss==-1 && mm==1)
{
ss=59;
mm=59;
hh=0;
}

return (temp1);
}

void displayTime();

};
 
 void Time::displayTime(void)


{
	
        cout<<setw(2)<<setfill('0')<<hh<<":";
	cout<<setw(2)<<setfill('0')<<mm<<":";
	cout<<setw(2)<<setfill('0')<<ss<<":";
}



int main()
{
 int a,b,c;
 cout<<"Enter the time in HH:MM:SS format"<<endl;
 cin>>a>>b>>c;
 Time X;
 Time T1(a,b,c);
 Time T2(a,b,c);
 cout<<"Input Time is            ";
 T1.displayTime();
 ++T1;
 cout<<endl<<"Time after increment     ";
 T1.displayTime();
 --T2;
 cout<<endl<<"Time after decrement     ";
 T2.displayTime();
 cout<<endl;
}



