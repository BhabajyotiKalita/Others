#include<stdio.h>
main()
{
int n;
float x,y;
printf("\n Enter value of n:");
scanf("%d",&n);
printf("\n Enter value of x:");
scanf("%f",&x);
switch(n)
{
case 1:y=n+x;
break;
case 2:y=1+x/n;
break;
case 3:y=n+3*x;
break;
default:y=1+n*x;
}
printf("\n y=%.2f \n",y);
}

