#include<stdio.h>
main()
{
int a,b,sum;
printf("\nEnter the 1st number:");
scanf("%d",&a);
printf("\nEnter the 2nd number:");
scanf("%d",&b);
sum=a+b;
printf("\n%d + %d = %d\n",a,b,sum);
}
