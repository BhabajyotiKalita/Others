#include<stdio.h>
main()
{
char c;
printf("\nEnter a character:");
scanf("%c",&c);
printf("ASCII value of %c= %d\n",c,c);
}

