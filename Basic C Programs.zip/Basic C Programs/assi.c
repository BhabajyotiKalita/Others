#include <stdio.h>
#include <stdlib.h>
int i,j,a[20][20],flag;
void read(int *p, int m,int o)
{
    printf("Enter the elements one by one \n");
    for(i=0; i<m; i++)
        for(j=0;j<o;j++)
        scanf("%d \t",&*((p+i*o)+j));
}
void transpose(int *p, int m,int o)
{
     for(i=0; i<m; i++)
        for(j=0;j<o;j++)
             a[j][i]=*((p+j*o)+i);
}
void symm(int *p,int m,int o)
{
    int flag;
    flag=1;
        for(i=0; i<m&&flag; i++)
            for(j=0; j<o;j++)
        {
            if((*(p+i*o)+j)!=a[j][i])
                flag=0;
            break;
        }
}
void display(int *p, int m, int o)
{
    read(p,m,o);
     printf("Enter matrix is :- \n");
     for(i=0; i<m; i++)
     {
        for(j=0;j<o;j++)
        printf("%6d",*((p+i*o)+j));
        printf("\n");
     }
     transpose(p,m,o);
       printf("The transpose of matrix is :\n");
        for(i=0; i<o; i++)
        {
        for(j=0;j<m;j++)
            printf("%8d",a[j][i]);
            printf("\n");
        }
        symm(p,m,o);
         if(flag==1)
        {
            printf("THE GIVEN MATRIX IS SYMMETRIC MATRIX \n");
            for(i=0; i<m; i++)
            {
            {
                for(j=0;j<o;j++)
                    printf("%9d",a[j][i]);
            }
            printf("\n");
            }
        }
        else
            printf("the matrix is not symmetric");
}

int main()
{
    int i,j,n,m,o,*p,*k,flag,a[20][20];
    printf("Enter the number of rows and columns \n");
    scanf("%d %d",&m,&o);
    p=(int*)malloc(m*o*sizeof(int));
    //k=(int*)malloc((m*o)* sizeof(int));
    display(p,m,o);

    /*printf("Enter the elements one by one \n");
    for(i=0; i<m; i++)
        for(j=0;j<o;j++)
        scanf("%d \t",&*(p+i*o+j));
    printf("Enter matrix is :- \n");
     for(i=0; i<m; i++)
     {
        for(j=0;j<o;j++)
        printf("%6d",*(p+i*o+j));
        printf("\n");
     }
     for(i=0; i<m; i++)
        for(j=0;j<o;j++)
             a[j][i]=*(p+j*o+i);
        //printf("check \n");
          //for(i=0; i<m; i++)
         //{
           //  for(j=0;j<o;j++)
            // printf("%8d",a[j][i]);
         //}

        printf("The transpose of matrix is :\n");
        for(i=0; i<o; i++)
        {
        for(j=0;j<m;j++)
            printf("%8d",a[j][i]);
            printf("\n");
        }
        flag=1;
        for(i=0; i<m&&flag; i++)
            for(j=0; j<o;j++)
        {
            if(*(p+i*o+j)!=a[j][i])
                flag=0;
            break;
        }
        if(flag==1)
        {
            printf("THE GIVEN MATRIC IS SYMMETRIC MATRIX \n");
            for(i=0; i<m; i++)
            {
            {
                for(j=0;j<o;j++)
                    printf("%9d",a[j][i]);
            }
            printf("\n");
            }
        }
        else
            printf("the matrix is not symmetric");
    return 0;*/
}

