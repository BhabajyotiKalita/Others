#include<iostream>
#include<cstdlib>
using namespace std;
class mydate
{
private:int d,m,y;
public: mydate(int a=29,int b=12,int c=2015)
{
d=a;
m=b;
y=c;
}

int diffdate(mydate &x);
};

int mydate::diffdate(mydate &x)
{
int nd1,nd2,a,b,c,d,e,f;

if(x.m==1)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(b*366)+(c*365));
}


else if(x.m==2)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31)+(b*366)+(c*365));
}
else if(x.m==3)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31+28)+(b*366)+(c*365));
}


else if(x.m==4)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*2)+(28)+(b*366)+(c*365));
}


else if(x.m==5)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*2)+(28)+(30)+(b*366)+(c*365));
}

else if(x.m==6)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*3)+(28)+(30)+(b*366)+(c*365));
}

else if(x.m==7)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*3)+(28)+(30*2)+(b*366)+(c*365));
}

else if(x.m==8)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*4)+(28)+(30*2)+(b*366)+(c*365));
}

else if(x.m==9)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*5)+(28)+(30*2)+(b*366)+(c*365));
}


else if(x.m==10)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*5)+(28)+(30*3)+(b*366)+(c*365));
}

else if(x.m==11)
{
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*6)+(28)+(30*3)+(b*366)+(c*365));
}

else if(x.m==12)
{ 
b=x.y/4;
c=x.y-b;
nd1=((x.d)+(31*6)+(28)+(30*4)+(b*366)+(c*365));
}

else
cout<<"Wrong value";

if(m==1)
{
b=y/4;
c=y-b;
nd2=((d)+(b*366)+(c*365));
}


else if(m==2)
{
b=y/4;
c=y-b;
nd2=((d)+(31)+(b*366)+(c*365));
}

else if(m==3)
{
b=y/4;
c=y-b;
nd2=((d)+(31+28)+(b*366)+(c*365));
}


else if(m==4)
{
b=y/4;
c=y-b;
nd2=((d)+(31*2)+(28)+(b*366)+(c*365));
}


else if(m==5)
{
b=y/4;
c=y-b;
nd2=((d)+(31*2)+(28)+(30)+(b*366)+(c*365));
}

else if(m==6)
{
b=y/4;
c=y-b;
nd2=((d)+(31*3)+(28)+(30)+(b*366)+(c*365));
}

else if(m==7)
{
b=y/4;
c=y-b;
nd2=((d)+(31*3)+(28)+(30*2)+(b*366)+(c*365));
}

else if(m==8)
{
b=y/4;
c=y-b;
nd2=((d)+(31*4)+(28)+(30*2)+(b*366)+(c*365));
}

else if(m==9)
{
b=y/4;
c=y-b;
nd2=((d)+(31*5)+(28)+(30*2)+(b*366)+(c*365));
}


else if(m==10)
{
b=y/4;
c=y-b;
nd2=((d)+(31*5)+(28)+(30*3)+(b*366)+(c*365));
}

else if(m==11)
{
b=y/4;
c=y-b;
nd2=((d)+(31*6)+(28)+(30*3)+(b*366)+(c*365));      
}                                                                                                                                                                                                                                                                                                        
else if(m==12)
{
b=y/4;
c=y-b;                                                                                                                                                                                          nd2=((d)+(31*6)+(28)+(30*4)+(b*366)+(c*365));
}

if((d<1 && d>31) || (m<0 && m>12))
{
cout<<"Wrong value";
exit(0);
}


if(nd2>nd1)
a=nd2-nd1;
else
a=nd1-nd2;
cout<<endl<<"No. of days between the dates is:  "<<a<<endl;

d=a/365;
e=(a%365)/30;
f=(a%365)%30;

cout<<endl<<"Your age is  "<<d<<" Years  "<<e<<"  Months  and  "<<f<<"  Days"<<endl;

cout<<endl<<"YOU ARE";
if(d>=0 && d<=12)
cout<<"  A BABY";
else if(d>=13 && d<=19)
cout<<" A TEENAGER";
else if(d>=20)
cout<<" AN ADULT";
else if(d>=60)
cout<<" A SENIOR CITIZEN";
cout<<endl<<endl;

}
main()
{
int a,b,c,a1,b1,c1;
cout<<"ENTER YOUR BIRTH DATE, MONTH and YEAR:\n";
cin>>a>>b>>c;
mydate x(a,b,c);
cout<<"ENTER TODAY'S DATE, MONTH and YEAR:\n";
cin>>a1>>b1>>c1;

mydate y(a1,b1,c1);
int j=y.diffdate(x);
}
